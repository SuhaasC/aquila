#!/bin/bash
echo "Starting Aquilastrat website..."
npm install --production
npm start
